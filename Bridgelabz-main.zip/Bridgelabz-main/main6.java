import java.util.Scanner;

class DoubleOpt {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double a = input.nextDouble();
        double b = input.nextDouble();
        double c = input.nextDouble();
        double res1 = a + b * c;
        double res2 = a * b + c;
        double res3 = c + a / b;
        double res4 = a % b + c;
        System.out.println("The results of Double Operations are " + res1 + ", " + res2
                + ", " + res3 + ", " + res4);
    }
}